import { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Smart responses based on keywords
const getBotResponse = (msg) => {
  const m = msg.toLowerCase()

  if (m.includes('restcontroller') || m.includes('controller'))
    return `**@RestController** combines two annotations:\n\n• **@Controller** — marks it as a Spring MVC controller\n• **@ResponseBody** — automatically serializes return values to JSON\n\nSo instead of returning views/HTML, it returns data directly! Use it for all your REST API endpoints. 🎯`

  if (m.includes('@entity') || m.includes('entity'))
    return `**@Entity** marks a Java class as a JPA entity — meaning Spring will create a database table for it automatically.\n\nYou also need:\n• **@Id** — marks the primary key\n• **@GeneratedValue** — auto-increments the ID\n• **@Column** — customizes column properties\n\nSpring Boot creates the table schema automatically! ✨`

  if (m.includes('jpa') || m.includes('repository'))
    return `**JpaRepository** gives you CRUD methods for free:\n\n• \`save(entity)\` — create or update\n• \`findById(id)\` — find one\n• \`findAll()\` — get all\n• \`deleteById(id)\` — delete\n\nYou can also add custom queries just by writing the method name:\n\`findByEmail(String email)\` — Spring generates the SQL! 🪄`

  if (m.includes('jwt') || m.includes('token') || m.includes('auth'))
    return `**JWT (JSON Web Token)** is how your app handles authentication:\n\n1. User logs in → Backend validates credentials\n2. Backend generates a JWT token (signed secret)\n3. Frontend stores it in localStorage\n4. Every API request sends: \`Authorization: Bearer <token>\`\n5. Backend validates the token on each request\n\nYour UcaLearn project already has full JWT security configured! 🔒`

  if (m.includes('react') || m.includes('component') || m.includes('hook'))
    return `**React Hooks** are the modern way to add logic to components:\n\n• **useState** — store and update values\n• **useEffect** — run code when component loads or updates\n• **useContext** — access global state (like your AuthContext)\n• **useNavigate** — navigate between pages\n\nExample:\n\`const [count, setCount] = useState(0)\`\n\nCall \`setCount(1)\` and React re-renders! ⚛️`

  if (m.includes('cors') || m.includes('cross origin'))
    return `**CORS** (Cross-Origin Resource Sharing) is a security feature.\n\nProblem: Your React app (port 5173) calls your Spring Boot API (port 8080). The browser blocks this by default!\n\nSolution: Configure CORS in Spring Boot to allow your frontend URL:\n\`registry.addMapping("/**").allowedOrigins("http://localhost:5173")\`\n\nYour UcaLearn backend already has this configured in CorsConfig.java! ✅`

  if (m.includes('spring boot') || m.includes('springboot'))
    return `**Spring Boot** is a Java framework that makes building REST APIs easy:\n\n• **Auto-configuration** — it figures out most settings for you\n• **Embedded Tomcat** — no need to deploy separately\n• **Spring Data JPA** — database operations without writing SQL\n• **Spring Security** — authentication and authorization\n\nYour UcaLearn backend runs on port 8080. Test it at: \`http://localhost:8080/api/auth/login\` 🚀`

  if (m.includes('quiz') || m.includes('score'))
    return `Your UcaLearn **Quiz System** works like this:\n\n1. Professor creates a quiz with multiple-choice questions\n2. Student opens quiz → countdown timer starts\n3. Student selects answers\n4. On submit → Backend auto-calculates the score\n5. Pass if score ≥ passingScore (default 60%)\n\nThe auto-correction is in **QuizService.submitQuiz()** — it compares answers and calculates percentage! 📝`

  if (m.includes('hello') || m.includes('hi') || m.includes('bonjour') || m.includes('salut'))
    return `Hello! 👋 I'm **UcaBot**, your AI learning assistant!\n\nI can help you with:\n• Spring Boot concepts and annotations\n• React & JavaScript\n• Your UcaLearn project code\n• JWT authentication\n• Database & JPA\n\nWhat would you like to learn about today? 🎓`

  if (m.includes('help') || m.includes('can you'))
    return `Of course! I can help you with:\n\n• **Spring Boot** — annotations, controllers, services, JPA\n• **React** — components, hooks, routing, state\n• **Your project** — UcaLearn architecture, how files connect\n• **Authentication** — JWT, login flow, security\n• **Database** — H2 for dev, MySQL for production\n\nJust ask your question! 💪`

  return `That's a great question! 🤔\n\nHere's what I know about **"${msg}"**:\n\nFor specific technical concepts in your UcaLearn project, try asking me about:\n• Spring Boot annotations (@Entity, @RestController, etc.)\n• React hooks (useState, useEffect)\n• JWT authentication\n• JPA and database concepts\n\nOr ask me to explain any part of your project code! 💡`
}

const suggestions = [
  "What is @RestController?",
  "Explain JPA Repository",
  "How does JWT work?",
  "What are React hooks?",
]

export default function ChatbotPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [messages, setMessages] = useState([{
    id: 1, role: 'bot',
    text: `Hello **${user?.firstName}**! 👋 I'm **UcaBot**, your AI learning assistant for UcaLearn!\n\nI can explain Spring Boot, React, your project architecture, or any concept you're learning. What's your question?`,
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }])
  const [input, setInput]         = useState('')
  const [typing, setTyping]       = useState(false)
  const bottomRef                  = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  const sendMessage = async (text) => {
    const userText = text || input.trim()
    if (!userText) return

    const userMsg = {
      id: Date.now(), role: 'user', text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setTyping(true)

    await new Promise(r => setTimeout(r, 800 + Math.random() * 600))

    const botText = getBotResponse(userText)
    const botMsg  = {
      id: Date.now() + 1, role: 'bot', text: botText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
    setMessages(prev => [...prev, botMsg])
    setTyping(false)
  }

  // Simple markdown-like renderer
  const renderText = (text) => {
    return text.split('\n').map((line, i) => {
      const parts = line.split(/\*\*(.*?)\*\*/g)
      return (
        <span key={i}>
          {parts.map((part, j) => j % 2 === 1 ? <strong key={j}>{part}</strong> : part)}
          {i < text.split('\n').length - 1 && <br />}
        </span>
      )
    })
  }

  return (
    <div style={{ display:'flex', height:'100vh', background:'#f5f3ee' }}>
      {/* Sidebar-like nav */}
      <div style={{ width:60, background:'#1a1a2e', display:'flex', flexDirection:'column', alignItems:'center', padding:'16px 0', gap:8 }}>
        <div style={{ width:36, height:36, background:'#e8490f', borderRadius:9, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:17, color:'white', marginBottom:16 }}>U</div>
        <div onClick={() => navigate(-1)} style={{ width:36, height:36, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', color:'rgba(255,255,255,0.4)', cursor:'pointer', fontSize:16, background:'rgba(255,255,255,0.06)' }} title="Back">←</div>
      </div>

      {/* Chat area */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', maxWidth:780, margin:'0 auto', width:'100%' }}>
        {/* Header */}
        <div style={{ background:'white', padding:'16px 24px', display:'flex', alignItems:'center', gap:14, borderBottom:'1px solid rgba(0,0,0,0.06)', boxShadow:'0 2px 8px rgba(0,0,0,0.04)' }}>
          <div style={{ width:44, height:44, background:'linear-gradient(135deg,#e8490f,#2563ff)', borderRadius:14, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>🤖</div>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:'Syne,sans-serif', fontSize:15, fontWeight:700, color:'#1a1a2e' }}>UcaBot — AI Assistant</div>
            <div style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'#00b894' }}>
              <div style={{ width:6, height:6, background:'#00b894', borderRadius:'50%' }}></div>
              Online • Always ready to help
            </div>
          </div>
          <div style={{ fontSize:11, color:'#6b6880', background:'rgba(0,0,0,0.04)', padding:'5px 12px', borderRadius:100 }}>PFE Assistant</div>
        </div>

        {/* Messages */}
        <div style={{ flex:1, overflowY:'auto', padding:'20px 24px', display:'flex', flexDirection:'column', gap:16 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{ display:'flex', gap:10, flexDirection: msg.role === 'user' ? 'row-reverse' : 'row', alignItems:'flex-end' }}>
              <div style={{ width:30, height:30, borderRadius:'50%', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14,
                background: msg.role === 'bot' ? 'linear-gradient(135deg,#e8490f,#2563ff)' : '#e8490f',
                color:'white', fontWeight:700
              }}>
                {msg.role === 'bot' ? '🤖' : user?.firstName?.[0]}
              </div>
              <div style={{ maxWidth:'72%' }}>
                <div style={{ padding:'12px 16px', borderRadius:16, fontSize:13, lineHeight:1.6,
                  background: msg.role === 'bot' ? 'white' : '#1a1a2e',
                  color: msg.role === 'bot' ? '#1a1a2e' : 'rgba(255,255,255,0.9)',
                  borderBottomLeftRadius: msg.role === 'bot' ? 4 : 16,
                  borderBottomRightRadius: msg.role === 'user' ? 4 : 16,
                  boxShadow: msg.role === 'bot' ? '0 2px 8px rgba(0,0,0,0.06)' : 'none'
                }}>
                  {renderText(msg.text)}
                </div>
                <div style={{ fontSize:10, color:'#6b6880', marginTop:4, textAlign: msg.role === 'user' ? 'right' : 'left' }}>{msg.time}</div>
              </div>
            </div>
          ))}

          {typing && (
            <div style={{ display:'flex', gap:10, alignItems:'flex-end' }}>
              <div style={{ width:30, height:30, borderRadius:'50%', background:'linear-gradient(135deg,#e8490f,#2563ff)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14 }}>🤖</div>
              <div style={{ background:'white', padding:'14px 18px', borderRadius:16, borderBottomLeftRadius:4, boxShadow:'0 2px 8px rgba(0,0,0,0.06)' }}>
                <div style={{ display:'flex', gap:4 }}>
                  {[0,1,2].map(i => <div key={i} style={{ width:6, height:6, borderRadius:'50%', background:'#6b6880', animation:`pulse 1.2s ease ${i*0.2}s infinite` }}></div>)}
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Suggestions */}
        {messages.length <= 2 && (
          <div style={{ padding:'0 24px 12px', display:'flex', gap:8, flexWrap:'wrap' }}>
            {suggestions.map(s => (
              <button key={s} onClick={() => sendMessage(s)} style={{ padding:'7px 14px', background:'white', border:'1px solid rgba(0,0,0,0.08)', borderRadius:100, fontSize:12, color:'#6b6880', cursor:'pointer', transition:'all 0.15s' }}
                onMouseEnter={e => { e.target.style.borderColor='#e8490f'; e.target.style.color='#e8490f' }}
                onMouseLeave={e => { e.target.style.borderColor='rgba(0,0,0,0.08)'; e.target.style.color='#6b6880' }}>
                {s}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div style={{ background:'white', borderTop:'1px solid rgba(0,0,0,0.06)', padding:'14px 20px', display:'flex', gap:12 }}>
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key==='Enter' && sendMessage()}
            placeholder="Ask UcaBot anything about your project..."
            style={{ flex:1, background:'#f5f3ee', border:'none', borderRadius:10, padding:'10px 16px', fontSize:13, color:'#1a1a2e', outline:'none' }} />
          <button onClick={() => sendMessage()} disabled={!input.trim()} style={{ width:40, height:40, background:'#e8490f', border:'none', borderRadius:10, color:'white', fontSize:16, cursor:input.trim()?'pointer':'default', opacity:input.trim()?1:0.5, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>➤</button>
        </div>
      </div>
    </div>
  )
}
