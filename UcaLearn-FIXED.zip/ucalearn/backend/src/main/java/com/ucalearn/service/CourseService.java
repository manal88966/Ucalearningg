package com.ucalearn.service;

import com.ucalearn.model.Course;
import com.ucalearn.model.User;
import com.ucalearn.repository.CourseRepository;
import com.ucalearn.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseService {

    @Autowired private CourseRepository courseRepository;
    @Autowired private UserRepository userRepository;

    public List<Course> getAllPublished() {
        return courseRepository.findByPublishedTrue();
    }

    public List<Course> search(String keyword) {
        return courseRepository.findByPublishedTrueAndTitleContainingIgnoreCase(keyword);
    }

    public Course getById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
    }

    public List<Course> getByProfessor(Long professorId) {
        User prof = userRepository.findById(professorId)
                .orElseThrow(() -> new RuntimeException("Professor not found"));
        return courseRepository.findByProfessor(prof);
    }

    public Course create(Course course, Long professorId) {
        User prof = userRepository.findById(professorId)
                .orElseThrow(() -> new RuntimeException("Professor not found"));
        course.setProfessor(prof);
        return courseRepository.save(course);
    }

    public Course update(Long courseId, Course updated) {
        Course course = getById(courseId);
        course.setTitle(updated.getTitle());
        course.setDescription(updated.getDescription());
        course.setCategory(updated.getCategory());
        course.setLevel(updated.getLevel());
        course.setDurationHours(updated.getDurationHours());
        course.setThumbnail(updated.getThumbnail());
        return courseRepository.save(course);
    }

    public void delete(Long courseId) {
        courseRepository.deleteById(courseId);
    }

    public Course publish(Long courseId) {
        Course course = getById(courseId);
        course.setPublished(true);
        return courseRepository.save(course);
    }

    public List<Course> getAll() {
        return courseRepository.findAll();
    }
}
