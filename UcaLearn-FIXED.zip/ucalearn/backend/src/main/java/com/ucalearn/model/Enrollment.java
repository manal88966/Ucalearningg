package com.ucalearn.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;

@Entity
@Table(name = "enrollments", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"student_id", "course_id"})
})
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    @JsonIgnoreProperties({"enrollments","taughtCourses","quizResults","password"})
    private User student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    @JsonIgnoreProperties({"enrollments","lessons","quizzes","forumPosts"})
    private Course course;

    @Column(nullable = false)
    private Integer progress = 0;

    private boolean completed = false;
    private boolean certificateIssued = false;

    @Column(updatable = false)
    private LocalDateTime enrolledAt;
    private LocalDateTime completedAt;

    @PrePersist
    protected void onCreate() { enrolledAt = LocalDateTime.now(); }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public Integer getProgress() { return progress; }
    public void setProgress(Integer progress) { this.progress = progress; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public boolean isCertificateIssued() { return certificateIssued; }
    public void setCertificateIssued(boolean certificateIssued) { this.certificateIssued = certificateIssued; }
    public LocalDateTime getEnrolledAt() { return enrolledAt; }
    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final Enrollment e = new Enrollment();
        public Builder student(User v) { e.student = v; return this; }
        public Builder course(Course v) { e.course = v; return this; }
        public Builder progress(Integer v) { e.progress = v; return this; }
        public Builder completed(boolean v) { e.completed = v; return this; }
        public Builder certificateIssued(boolean v) { e.certificateIssued = v; return this; }
        public Enrollment build() { return e; }
    }
}
