package com.ucalearn.controller;

import com.ucalearn.model.*;
import com.ucalearn.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/quizzes")
@CrossOrigin(origins = "*")
public class QuizController {

    @Autowired private QuizService quizService;

    @GetMapping("/course/{courseId}")
    public List<Quiz> getByCourse(@PathVariable Long courseId) {
        return quizService.getByCourse(courseId);
    }

    @GetMapping("/{quizId}")
    public ResponseEntity<Quiz> getById(@PathVariable Long quizId) {
        return ResponseEntity.ok(quizService.getById(quizId));
    }

    @PostMapping("/course/{courseId}")
    public ResponseEntity<Quiz> create(@RequestBody Quiz quiz, @PathVariable Long courseId) {
        return ResponseEntity.ok(quizService.create(quiz, courseId));
    }

    @PostMapping("/{quizId}/submit")
    public ResponseEntity<QuizResult> submit(@PathVariable Long quizId,
                                              @RequestParam Long studentId,
                                              @RequestBody Map<Long, String> answers) {
        return ResponseEntity.ok(quizService.submitQuiz(quizId, studentId, answers));
    }

    @GetMapping("/student/{studentId}/results")
    public List<QuizResult> getStudentResults(@PathVariable Long studentId) {
        return quizService.getStudentResults(studentId);
    }
}
