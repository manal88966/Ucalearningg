package com.ucalearn.repository;
import com.ucalearn.model.QuizResult;
import com.ucalearn.model.User;
import com.ucalearn.model.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QuizResultRepository extends JpaRepository<QuizResult, Long> {
    List<QuizResult> findByStudent(User student);
    List<QuizResult> findByQuiz(Quiz quiz);
    boolean existsByStudentAndQuiz(User student, Quiz quiz);
}
