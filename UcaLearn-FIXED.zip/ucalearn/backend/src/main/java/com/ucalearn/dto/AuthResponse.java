package com.ucalearn.dto;

public class AuthResponse {
    private String token;
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String role;
    private String profilePicture;

    public AuthResponse() {}

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final AuthResponse r = new AuthResponse();
        public Builder token(String v) { r.token = v; return this; }
        public Builder id(Long v) { r.id = v; return this; }
        public Builder email(String v) { r.email = v; return this; }
        public Builder firstName(String v) { r.firstName = v; return this; }
        public Builder lastName(String v) { r.lastName = v; return this; }
        public Builder role(String v) { r.role = v; return this; }
        public Builder profilePicture(String v) { r.profilePicture = v; return this; }
        public AuthResponse build() { return r; }
    }
}
