package com.ucalearn.repository;
import com.ucalearn.model.ForumPost;
import com.ucalearn.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ForumPostRepository extends JpaRepository<ForumPost, Long> {
    List<ForumPost> findByCourseAndParentIsNull(Course course);
    List<ForumPost> findByParent(ForumPost parent);
}
