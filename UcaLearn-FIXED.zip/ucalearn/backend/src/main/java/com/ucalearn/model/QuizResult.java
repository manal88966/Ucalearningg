package com.ucalearn.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;

@Entity
@Table(name = "quiz_results")
public class QuizResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id")
    @JsonIgnoreProperties({"enrollments","taughtCourses","quizResults","password"})
    private User student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id")
    @JsonIgnoreProperties({"results","course","questions"})
    private Quiz quiz;

    private Integer score;
    private Integer correctAnswers;
    private Integer totalQuestions;
    private boolean passed;

    @Column(updatable = false)
    private LocalDateTime takenAt;

    @PrePersist
    protected void onCreate() { takenAt = LocalDateTime.now(); }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }
    public Quiz getQuiz() { return quiz; }
    public void setQuiz(Quiz quiz) { this.quiz = quiz; }
    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }
    public Integer getCorrectAnswers() { return correctAnswers; }
    public void setCorrectAnswers(Integer correctAnswers) { this.correctAnswers = correctAnswers; }
    public Integer getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(Integer totalQuestions) { this.totalQuestions = totalQuestions; }
    public boolean isPassed() { return passed; }
    public void setPassed(boolean passed) { this.passed = passed; }
    public LocalDateTime getTakenAt() { return takenAt; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final QuizResult r = new QuizResult();
        public Builder student(User v) { r.student = v; return this; }
        public Builder quiz(Quiz v) { r.quiz = v; return this; }
        public Builder score(Integer v) { r.score = v; return this; }
        public Builder correctAnswers(Integer v) { r.correctAnswers = v; return this; }
        public Builder totalQuestions(Integer v) { r.totalQuestions = v; return this; }
        public Builder passed(boolean v) { r.passed = v; return this; }
        public QuizResult build() { return r; }
    }
}
