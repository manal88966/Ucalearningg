package com.ucalearn.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "courses")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    private String category;
    private String level;
    private Integer durationHours;
    private String thumbnail;
    private Double rating = 0.0;
    private Integer ratingCount = 0;

    @Column(nullable = false)
    private boolean published = false;

    @Column(updatable = false)
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "professor_id", nullable = false)
    @JsonIgnoreProperties({"taughtCourses","enrollments","quizResults","password"})
    private User professor;

    @JsonIgnore
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Lesson> lessons;

    @JsonIgnore
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Enrollment> enrollments;

    @JsonIgnore
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Quiz> quizzes;

    @JsonIgnore
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<ForumPost> forumPosts;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now(); updatedAt = LocalDateTime.now(); }
    @PreUpdate
    protected void onUpdate() { updatedAt = LocalDateTime.now(); }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public Integer getDurationHours() { return durationHours; }
    public void setDurationHours(Integer durationHours) { this.durationHours = durationHours; }
    public String getThumbnail() { return thumbnail; }
    public void setThumbnail(String thumbnail) { this.thumbnail = thumbnail; }
    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }
    public Integer getRatingCount() { return ratingCount; }
    public void setRatingCount(Integer ratingCount) { this.ratingCount = ratingCount; }
    public boolean isPublished() { return published; }
    public void setPublished(boolean published) { this.published = published; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public User getProfessor() { return professor; }
    public void setProfessor(User professor) { this.professor = professor; }
    public List<Lesson> getLessons() { return lessons; }
    public List<Enrollment> getEnrollments() { return enrollments; }
    public List<Quiz> getQuizzes() { return quizzes; }
    public int getEnrollmentCount() { return enrollments == null ? 0 : enrollments.size(); }
    public int getLessonCount() { return lessons == null ? 0 : lessons.size(); }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final Course c = new Course();
        public Builder title(String v) { c.title = v; return this; }
        public Builder description(String v) { c.description = v; return this; }
        public Builder category(String v) { c.category = v; return this; }
        public Builder level(String v) { c.level = v; return this; }
        public Builder durationHours(Integer v) { c.durationHours = v; return this; }
        public Builder thumbnail(String v) { c.thumbnail = v; return this; }
        public Builder rating(Double v) { c.rating = v; return this; }
        public Builder ratingCount(Integer v) { c.ratingCount = v; return this; }
        public Builder professor(User v) { c.professor = v; return this; }
        public Builder published(boolean v) { c.published = v; return this; }
        public Course build() { return c; }
    }
}
