package com.ucalearn.controller;

import com.ucalearn.model.Enrollment;
import com.ucalearn.service.EnrollmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/enrollments")
@CrossOrigin(origins = "*")
public class EnrollmentController {

    @Autowired private EnrollmentService enrollmentService;

    @PostMapping("/enroll")
    public ResponseEntity<Enrollment> enroll(@RequestParam Long studentId,
                                              @RequestParam Long courseId) {
        return ResponseEntity.ok(enrollmentService.enroll(studentId, courseId));
    }

    @GetMapping("/student/{studentId}")
    public List<Enrollment> getByStudent(@PathVariable Long studentId) {
        return enrollmentService.getStudentEnrollments(studentId);
    }

    @PatchMapping("/{enrollmentId}/progress")
    public ResponseEntity<Enrollment> updateProgress(@PathVariable Long enrollmentId,
                                                      @RequestParam Integer progress) {
        return ResponseEntity.ok(enrollmentService.updateProgress(enrollmentId, progress));
    }

    @GetMapping("/student/{studentId}/stats")
    public ResponseEntity<Map<String, Object>> getStats(@PathVariable Long studentId) {
        return ResponseEntity.ok(enrollmentService.getStudentStats(studentId));
    }
}
