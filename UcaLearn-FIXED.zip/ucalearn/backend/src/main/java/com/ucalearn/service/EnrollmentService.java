package com.ucalearn.service;

import com.ucalearn.model.Course;
import com.ucalearn.model.Enrollment;
import com.ucalearn.model.User;
import com.ucalearn.repository.CourseRepository;
import com.ucalearn.repository.EnrollmentRepository;
import com.ucalearn.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EnrollmentService {

    @Autowired private EnrollmentRepository enrollmentRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private CourseRepository courseRepository;

    public Enrollment enroll(Long studentId, Long courseId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        if (enrollmentRepository.existsByStudentAndCourse(student, course)) {
            throw new RuntimeException("Already enrolled");
        }

        Enrollment enrollment = Enrollment.builder()
                .student(student)
                .course(course)
                .progress(0)
                .completed(false)
                .build();

        return enrollmentRepository.save(enrollment);
    }

    public List<Enrollment> getStudentEnrollments(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return enrollmentRepository.findByStudent(student);
    }

    public Enrollment updateProgress(Long enrollmentId, Integer progress) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollment.setProgress(Math.min(100, Math.max(0, progress)));
        if (enrollment.getProgress() == 100) {
            enrollment.setCompleted(true);
            enrollment.setCompletedAt(LocalDateTime.now());
        }
        return enrollmentRepository.save(enrollment);
    }

    public Map<String, Object> getStudentStats(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        long totalEnrolled = enrollmentRepository.countByStudent(student);
        long completed     = enrollmentRepository.countByStudentAndCompleted(student, true);
        List<Enrollment> enrollments = enrollmentRepository.findByStudent(student);
        double avgProgress = enrollments.stream()
                .mapToInt(Enrollment::getProgress)
                .average().orElse(0.0);

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalEnrolled",   totalEnrolled);
        stats.put("completed",       completed);
        stats.put("inProgress",      totalEnrolled - completed);
        stats.put("averageProgress", Math.round(avgProgress));
        stats.put("certificates",    completed);
        return stats;
    }
}
