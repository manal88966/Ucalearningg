package com.ucalearn.repository;
import com.ucalearn.model.Course;
import com.ucalearn.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByPublishedTrue();
    List<Course> findByProfessor(User professor);
    List<Course> findByCategory(String category);
    List<Course> findByPublishedTrueAndTitleContainingIgnoreCase(String keyword);
    long countByProfessor(User professor);
}
