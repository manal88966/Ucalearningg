package com.ucalearn.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "questions")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String questionText;

    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;

    @Column(nullable = false)
    private String correctAnswer;

    @Column(columnDefinition = "TEXT")
    private String explanation;

    private Integer orderIndex;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id")
    @JsonIgnore
    private Quiz quiz;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String v) { this.questionText = v; }
    public String getOptionA() { return optionA; }
    public void setOptionA(String v) { this.optionA = v; }
    public String getOptionB() { return optionB; }
    public void setOptionB(String v) { this.optionB = v; }
    public String getOptionC() { return optionC; }
    public void setOptionC(String v) { this.optionC = v; }
    public String getOptionD() { return optionD; }
    public void setOptionD(String v) { this.optionD = v; }
    public String getCorrectAnswer() { return correctAnswer; }
    public void setCorrectAnswer(String v) { this.correctAnswer = v; }
    public String getExplanation() { return explanation; }
    public void setExplanation(String v) { this.explanation = v; }
    public Integer getOrderIndex() { return orderIndex; }
    public void setOrderIndex(Integer v) { this.orderIndex = v; }
    public Quiz getQuiz() { return quiz; }
    public void setQuiz(Quiz quiz) { this.quiz = quiz; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final Question q = new Question();
        public Builder questionText(String v) { q.questionText = v; return this; }
        public Builder optionA(String v) { q.optionA = v; return this; }
        public Builder optionB(String v) { q.optionB = v; return this; }
        public Builder optionC(String v) { q.optionC = v; return this; }
        public Builder optionD(String v) { q.optionD = v; return this; }
        public Builder correctAnswer(String v) { q.correctAnswer = v; return this; }
        public Builder explanation(String v) { q.explanation = v; return this; }
        public Builder orderIndex(Integer v) { q.orderIndex = v; return this; }
        public Builder quiz(Quiz v) { q.quiz = v; return this; }
        public Question build() { return q; }
    }
}
