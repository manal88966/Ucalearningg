package com.ucalearn.controller;

import com.ucalearn.model.Course;
import com.ucalearn.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin(origins = "*")
public class CourseController {

    @Autowired private CourseService courseService;

    // Public
    @GetMapping("/public")
    public List<Course> getPublished() {
        return courseService.getAllPublished();
    }

    @GetMapping("/public/search")
    public List<Course> search(@RequestParam String q) {
        return courseService.search(q);
    }

    @GetMapping("/public/{id}")
    public ResponseEntity<Course> getById(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.getById(id));
    }

    // Protected
    @GetMapping
    public List<Course> getAll() {
        return courseService.getAll();
    }

    @GetMapping("/professor/{professorId}")
    public List<Course> getByProfessor(@PathVariable Long professorId) {
        return courseService.getByProfessor(professorId);
    }

    @PostMapping("/professor/{professorId}")
    public ResponseEntity<Course> create(@RequestBody Course course,
                                          @PathVariable Long professorId) {
        return ResponseEntity.ok(courseService.create(course, professorId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Course> update(@PathVariable Long id, @RequestBody Course course) {
        return ResponseEntity.ok(courseService.update(id, course));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        courseService.delete(id);
        return ResponseEntity.ok(java.util.Map.of("message", "Course deleted"));
    }

    @PatchMapping("/{id}/publish")
    public ResponseEntity<Course> publish(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.publish(id));
    }
}
