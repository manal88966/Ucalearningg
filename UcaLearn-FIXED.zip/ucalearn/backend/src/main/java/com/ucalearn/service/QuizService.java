package com.ucalearn.service;

import com.ucalearn.model.*;
import com.ucalearn.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class QuizService {

    @Autowired private QuizRepository quizRepository;
    @Autowired private QuizResultRepository quizResultRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private CourseRepository courseRepository;

    public List<Quiz> getByCourse(Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        return quizRepository.findByCourse(course);
    }

    public Quiz getById(Long quizId) {
        return quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz not found"));
    }

    public Quiz create(Quiz quiz, Long courseId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        quiz.setCourse(course);
        if (quiz.getQuestions() != null) {
            for (Question q : quiz.getQuestions()) {
                q.setQuiz(quiz);
            }
        }
        return quizRepository.save(quiz);
    }

    public QuizResult submitQuiz(Long quizId, Long studentId, Map<Long, String> answers) {
        Quiz quiz = getById(quizId);
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        List<Question> questions = quiz.getQuestions();
        int correct = 0;

        for (Question q : questions) {
            String given = answers.get(q.getId());
            if (given != null && given.equalsIgnoreCase(q.getCorrectAnswer())) {
                correct++;
            }
        }

        int total        = questions.size();
        int scorePercent = total > 0 ? (int) Math.round((correct * 100.0) / total) : 0;
        boolean passed   = scorePercent >= quiz.getPassingScore();

        QuizResult result = QuizResult.builder()
                .student(student)
                .quiz(quiz)
                .score(scorePercent)
                .correctAnswers(correct)
                .totalQuestions(total)
                .passed(passed)
                .build();

        return quizResultRepository.save(result);
    }

    public List<QuizResult> getStudentResults(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        return quizResultRepository.findByStudent(student);
    }
}
