package com.ucalearn.service;

import com.ucalearn.model.User;
import com.ucalearn.repository.CourseRepository;
import com.ucalearn.repository.EnrollmentRepository;
import com.ucalearn.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminService {

    @Autowired private UserRepository userRepository;
    @Autowired private CourseRepository courseRepository;
    @Autowired private EnrollmentRepository enrollmentRepository;

    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents",    userRepository.countByRole(User.Role.STUDENT));
        stats.put("totalProfessors",  userRepository.countByRole(User.Role.PROFESSOR));
        stats.put("totalCourses",     courseRepository.count());
        stats.put("totalEnrollments", enrollmentRepository.count());
        return stats;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    public User toggleUserStatus(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setActive(!user.isActive());
        return userRepository.save(user);
    }
}
