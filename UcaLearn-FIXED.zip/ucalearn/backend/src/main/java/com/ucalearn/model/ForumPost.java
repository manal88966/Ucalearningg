package com.ucalearn.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "forum_posts")
public class ForumPost {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(columnDefinition = "TEXT")
    private String content;

    private Integer likes = 0;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id")
    @JsonIgnoreProperties({"enrollments","taughtCourses","quizResults","password"})
    private User author;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id")
    @JsonIgnore
    private Course course;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    @JsonIgnore
    private ForumPost parent;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
    private List<ForumPost> replies;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() { createdAt = LocalDateTime.now(); }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public Integer getLikes() { return likes; }
    public void setLikes(Integer likes) { this.likes = likes; }
    public User getAuthor() { return author; }
    public void setAuthor(User author) { this.author = author; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public ForumPost getParent() { return parent; }
    public void setParent(ForumPost parent) { this.parent = parent; }
    public List<ForumPost> getReplies() { return replies; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public static Builder builder() { return new Builder(); }
    public static class Builder {
        private final ForumPost p = new ForumPost();
        public Builder title(String v) { p.title = v; return this; }
        public Builder content(String v) { p.content = v; return this; }
        public Builder author(User v) { p.author = v; return this; }
        public Builder course(Course v) { p.course = v; return this; }
        public ForumPost build() { return p; }
    }
}
