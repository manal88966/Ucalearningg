package com.ucalearn.config;

import com.ucalearn.model.*;
import com.ucalearn.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired private UserRepository userRepo;
    @Autowired private CourseRepository courseRepo;
    @Autowired private EnrollmentRepository enrollmentRepo;
    @Autowired private QuizRepository quizRepo;
    @Autowired private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepo.count() > 0) return;

        // ── USERS ─────────────────────────────────────
        User prof1 = userRepo.save(User.builder()
                .firstName("Admin").lastName("UCA")
                .email("admin@ucalearn.ma")
                .password(passwordEncoder.encode("admin123"))
                .role(User.Role.ADMIN).active(true).build());

        User prof2 = userRepo.save(User.builder()
                .firstName("Karim").lastName("Hassan")
                .email("k.hassan@ucalearn.ma")
                .password(passwordEncoder.encode("prof123"))
                .role(User.Role.PROFESSOR).bio("Backend Expert").active(true).build());

        User prof3 = userRepo.save(User.builder()
                .firstName("Fatima").lastName("Benali")
                .email("f.benali@ucalearn.ma")
                .password(passwordEncoder.encode("prof123"))
                .role(User.Role.PROFESSOR).bio("React Specialist").active(true).build());

        User student1 = userRepo.save(User.builder()
                .firstName("Sara").lastName("Ahmed")
                .email("sara@ucalearn.ma")
                .password(passwordEncoder.encode("student123"))
                .role(User.Role.STUDENT).active(true).build());

        User student2 = userRepo.save(User.builder()
                .firstName("Lina").lastName("Berrada")
                .email("lina@ucalearn.ma")
                .password(passwordEncoder.encode("student123"))
                .role(User.Role.STUDENT).active(true).build());

        User student3 = userRepo.save(User.builder()
                .firstName("Youssef").lastName("Tahir")
                .email("youssef@ucalearn.ma")
                .password(passwordEncoder.encode("student123"))
                .role(User.Role.STUDENT).active(true).build());

        // ── COURSES ───────────────────────────────────
        Course c1 = courseRepo.save(Course.builder()
                .title("Spring Boot Mastery").category("Backend").level("Beginner")
                .description("Master Spring Boot from scratch. REST APIs, JPA, Security and more.")
                .durationHours(40).thumbnail("☕").rating(4.9).ratingCount(128)
                .professor(prof2).published(true).build());

        Course c2 = courseRepo.save(Course.builder()
                .title("React & Modern JavaScript").category("Frontend").level("Intermediate")
                .description("Build modern UIs with React 18, hooks, state management and Tailwind CSS.")
                .durationHours(35).thumbnail("⚛️").rating(4.8).ratingCount(95)
                .professor(prof3).published(true).build());

        Course c3 = courseRepo.save(Course.builder()
                .title("SQL & JPA Deep Dive").category("Database").level("Beginner")
                .description("Understand relational databases, SQL queries and Spring Data JPA.")
                .durationHours(28).thumbnail("🗄️").rating(4.7).ratingCount(74)
                .professor(prof2).published(true).build());

        Course c4 = courseRepo.save(Course.builder()
                .title("Full Stack Spring + React").category("Full Stack").level("Advanced")
                .description("Build complete real-world apps with Spring Boot and React.")
                .durationHours(60).thumbnail("🚀").rating(5.0).ratingCount(210)
                .professor(prof2).published(true).build());

        courseRepo.save(Course.builder()
                .title("UI/UX Design Fundamentals").category("Design").level("Beginner")
                .description("Learn design thinking, wireframing and prototyping for modern web apps.")
                .durationHours(20).thumbnail("🎨").rating(4.6).ratingCount(61)
                .professor(prof3).published(true).build());

        // ── ENROLLMENTS ───────────────────────────────
        enrollmentRepo.save(Enrollment.builder().student(student1).course(c1).progress(72).completed(false).build());
        enrollmentRepo.save(Enrollment.builder().student(student1).course(c2).progress(45).completed(false).build());
        enrollmentRepo.save(Enrollment.builder().student(student1).course(c3).progress(100).completed(true).certificateIssued(true).build());
        enrollmentRepo.save(Enrollment.builder().student(student2).course(c1).progress(30).completed(false).build());
        enrollmentRepo.save(Enrollment.builder().student(student2).course(c4).progress(60).completed(false).build());
        enrollmentRepo.save(Enrollment.builder().student(student3).course(c2).progress(100).completed(true).certificateIssued(true).build());

        // ── QUIZ ──────────────────────────────────────
        Quiz quiz1 = new Quiz();
        quiz1.setTitle("Spring Boot Basics Quiz");
        quiz1.setCourse(c1);
        quiz1.setTimeLimitMinutes(10);
        quiz1.setPassingScore(60);

        List<Question> questions = new ArrayList<>();

        Question q1 = new Question();
        q1.setQuestionText("What annotation marks a class as a REST controller?");
        q1.setOptionA("@Controller"); q1.setOptionB("@RestController");
        q1.setOptionC("@Service");    q1.setOptionD("@Component");
        q1.setCorrectAnswer("B");
        q1.setExplanation("@RestController = @Controller + @ResponseBody");
        q1.setOrderIndex(1); q1.setQuiz(quiz1);
        questions.add(q1);

        Question q2 = new Question();
        q2.setQuestionText("What annotation maps a Java class to a database table?");
        q2.setOptionA("@Table"); q2.setOptionB("@Model");
        q2.setOptionC("@Entity"); q2.setOptionD("@Column");
        q2.setCorrectAnswer("C");
        q2.setExplanation("@Entity marks the class as a JPA entity mapped to a DB table.");
        q2.setOrderIndex(2); q2.setQuiz(quiz1);
        questions.add(q2);

        Question q3 = new Question();
        q3.setQuestionText("What does JpaRepository.save() do?");
        q3.setOptionA("Only creates"); q3.setOptionB("Only updates");
        q3.setOptionC("Creates or updates"); q3.setOptionD("Deletes");
        q3.setCorrectAnswer("C");
        q3.setExplanation("save() performs INSERT or UPDATE based on whether the entity has an ID.");
        q3.setOrderIndex(3); q3.setQuiz(quiz1);
        questions.add(q3);

        Question q4 = new Question();
        q4.setQuestionText("What is the default port of a Spring Boot app?");
        q4.setOptionA("3000"); q4.setOptionB("8080");
        q4.setOptionC("5173"); q4.setOptionD("80");
        q4.setCorrectAnswer("B");
        q4.setExplanation("Spring Boot uses embedded Tomcat on port 8080 by default.");
        q4.setOrderIndex(4); q4.setQuiz(quiz1);
        questions.add(q4);

        Question q5 = new Question();
        q5.setQuestionText("Which annotation maps HTTP GET requests?");
        q5.setOptionA("@PostMapping"); q5.setOptionB("@PutMapping");
        q5.setOptionC("@GetMapping");  q5.setOptionD("@DeleteMapping");
        q5.setCorrectAnswer("C");
        q5.setExplanation("@GetMapping maps HTTP GET requests to handler methods.");
        q5.setOrderIndex(5); q5.setQuiz(quiz1);
        questions.add(q5);

        quiz1.setQuestions(questions);
        quizRepo.save(quiz1);

        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║  ✅ Data loaded! Test accounts:           ║");
        System.out.println("║  admin@ucalearn.ma   / admin123           ║");
        System.out.println("║  k.hassan@ucalearn.ma / prof123           ║");
        System.out.println("║  sara@ucalearn.ma    / student123         ║");
        System.out.println("╚══════════════════════════════════════════╝");
    }
}
