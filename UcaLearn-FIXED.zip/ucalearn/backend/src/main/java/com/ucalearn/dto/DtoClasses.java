package com.ucalearn.dto;
// DTOs are in separate files: LoginRequest.java, RegisterRequest.java, AuthResponse.java
