package com.ucalearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UcaLearnApplication {
    public static void main(String[] args) {
        SpringApplication.run(UcaLearnApplication.class, args);
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   UcaLearn Backend Started! ✅        ║");
        System.out.println("║   API: http://localhost:8080/api      ║");
        System.out.println("║   H2:  http://localhost:8080/h2-console║");
        System.out.println("╚══════════════════════════════════════╝");
    }
}
